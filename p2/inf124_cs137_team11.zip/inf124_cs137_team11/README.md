Uyen Thuy Phuong Dinh

Jonathan Jin

Loc Duc Minh Khong

index.html (Home page)
Satisfy Requirement: 1

product_detail.html(Product Detail Page)
Satisfy Requirement: 2

cart.html (Checkout page)
Satisfy Requirement: 3,4

view_ordered (View Ordered page)
Satify Requirement: 1

Deployed Website Link:
http://3.101.37.212:38234/cs137-spring21-team11/index.html
Satisfy Requirement: 5

MUST USE UCI VPN on UCIFULL channel to access!

SQL Database:
META-INF/context.xml (if you want to change UN/PW)
Default UN:localhost
Default PW:My6$Password

The Home page will be the main starting page which display all products in rows and columns. Users can navigate to the Teamm, About, View Ordered pages by clicking on the 
labeled navigation bar located on the top.

Clicking on a product image in the Home page will redirect to the Product Detail page with product information. User's will be able to input quantity and press Add to Cart. 

Users can press the Checkout on the navigation bar to be redirected to a Cart page where they will be able to input personal information, shipping address, delivery options, 
and payment info. If any fields are left blank, the wepage with notify the users where the user needs to input the information. Webpage will check for correct input such as zip 
code length, credit card information, and expiry date (no old dates). Once all order information input is correctely added, the user will click the "Review Order/Place Order" button.

Clicking on View Ordered from the Navigation bar will display the last 5 products ordered once the user inputs an email address. User will able be able give a rating for the products 
ordered here. 

Clicking on Team on the navigation bar will lead to the Team page with names and email address of Group 11 team members who developed this webpage. Clicking on About on the navigation 
bar will lead to a description on what this webpage about and some FAQ about the fictional sale of product on this webpage.
